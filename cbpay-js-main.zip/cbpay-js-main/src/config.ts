export const DEFAULT_HOST = 'https://pay.coinbase.com';
